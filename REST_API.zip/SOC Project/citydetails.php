<?php
$city = $_GET['q'];

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://city-and-state-search-api.p.rapidapi.com/cities/$city",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: city-and-state-search-api.p.rapidapi.com",
        "X-RapidAPI-Key:7d404d4562mshabcd2912a57ec7ap181217jsna0b7caaf1660"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $cityDetails = json_decode($response, true);
}

function displayData($label, $value)
{
    echo '<tr>
        <th>' . $label . ':</th>
        <th>' . $value . '</th>
    </tr>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    <title>City Details</title>
</head>
<body>
<div id="main">
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a> &nbsp; <a  href="rest.php"> RestFull Web Service</a></div>
<h1><center>City Information</center></h1>
<div>
<div class="row">
<div class="col-2">&nbsp;</div>
<div class="col-8">
<div class="clearfix">&nbsp;</div>
<div class="container">
            
            <hr />
    <table class="table table-striped" >
        <?php
            $data = [
                ['City ID', $cityDetails['id']],
                ['City Name', $cityDetails['name']],
                ['State Name', $cityDetails['state_name'] ?? 'No data available'],
                ['Country Name', $cityDetails['country_name'] ?? 'No data available'],
            ];

            foreach ($data as $row) {
                displayData($row[0], $row[1]);
            }
        ?>

        <tr>
        <th>Country Flag:</th>
        <th>
            <?php
                echo "<img src='https://flagcdn.com/w320/" . strtolower($cityDetails['country_code']) . ".png' alt='" . $cityDetails['country_name'] . " Flag' width='100' height='50'>";
            ?>
        </th>
        </tr>
        <tr>
        <th colspan="2">
            <iframe
                width="100%"
                height="250"
                frameborder="1" style="border:1"
                referrerpolicy="no-referrer-when-downgrade"
                src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDsHr7Ogo7rhF_qElXLx4jiIuDz5zzsOUQ&q=<?php echo urlencode($cityDetails['name'] . ', ' . $cityDetails['country_name']); ?>&zoom=12"
                llowfullscreen>
            </iframe>
        </th>
        </tr>
    </table>
</div> 
</div>
</div>
</div>
</div>
</body>
</html>