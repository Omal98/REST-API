<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>City Information</title>
        <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
        
    <script>
        function showCities(event, input) {
            if (event.keyCode === 13) {
                var searchTerm = input.value.trim();
                if (searchTerm === "") {
                    document.getElementById("city-details").innerHTML = "";
                    return;
                }

                const xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        document.getElementById("city-details").innerHTML = this.responseText;
                    }
                };
                xhr.open("GET", "getinformation.php?q=" + searchTerm, true);
                xhr.send();
            }
        }
    </script>
</head>
<body>
<div id="main">
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a>&nbsp; <a href="rest.php"> RestFull Web Service</a></div>
    <div id="main">
    <div id="content">
    <div class="container">
    <div class="row">
    <div class="col-md-1">&nbsp;</div>
    <div class="col-md-10">
        <h5 class="text-center">City Information</h5>
            <div class="container">
                <h5 class="text text-primary">
                    <div class="row">
                    <div class="col-md-4">Search Cities:</div>
                    <div class="col-md-8">
                        <input type="text" id="search" class="form-control" onkeyup="showCities(event, this)" />
                    </div>
                    </div>
                </h5>
                <hr />
            <div id="city-details">Load Cities</div>
    </div>
    </div>
    <div class="col-md-1">&nbsp;</div>
    </div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>
 