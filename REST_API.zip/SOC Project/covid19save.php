<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "covid2023";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: covid-193.p.rapidapi.com",
        "X-RapidAPI-Key: 7d404d4562mshabcd2912a57ec7ap181217jsna0b7caaf1660"
    ],
]);
$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $data = json_decode($response, true);
    $c = $data['response'];
}
foreach ($c as $v) {
    $countryName = $v['country'];
    $population = $v['population'];
    $totalcases = $v['cases']['total'];
    $deaths = $v['deaths']['total'];
    $tests = $v['tests']['total'];
    $continent = $v['continent'];
    $date = $v['day'];
    $sql = "INSERT INTO covidcases (countryName, population, totalcases, deaths, tests, continent, date)
            VALUES ('$countryName', '$population', '$totalcases', '$deaths', '$tests', '$continent', '$date')";
    if ($conn->query($sql) === TRUE) {    
    } else {
        echo "Error: ";
    }
}
echo "Data Insertion successfully";
$conn->close();
?>