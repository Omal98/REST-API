<?php

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: covid-193.p.rapidapi.com",
        "X-RapidAPI-Key: 7d404d4562mshabcd2912a57ec7ap181217jsna0b7caaf1660"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $result = json_decode($response, true);
    $c = $result['response'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    <title>COVID19 Information in Europe</title>
</head>
<body >
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a> &nbsp; <a  href="rest.php"> RestFull Web Service</a></div>
    <div class="container">
        <h1><center>COVID19 Information in Europe</center></h1>
        <table class="table">
            <tr>
                <th>Country</th>
                <th>Population</th>
                <th>Total Covid Cases</th>
                <th>Total Deaths</th>
                <th>Tests</th>
                <th>Continent</th>
            </tr>
            <?php foreach ($c as $v) {
                if ($v['continent'] == "Europe") { ?>
                    <tr>
                        <td><?php echo $v['country']; ?></td>
                        <td><?php echo $v['population'] ? $v['population'] : '0'; ?></td>
                        <td><?php echo $v['cases']['total'] ? $v['cases']['total'] : '0'; ?></td>
                        <td><?php echo $v['deaths']['total'] ? $v['deaths']['total'] : '0'; ?></td>
                        <td><?php echo $v['tests']['total'] ? $v['tests']['total'] : '0'; ?></td>
                        <td><?php echo $v['continent']; ?></td>
                    </tr>
            <?php }
            } ?>
        </table>
    </div>
</body>
</html>