<?php 
//set path
$c= $_GET['q'];
$path="https://restcountries.com/v3.1/alpha/$c";
$data = json_decode(file_get_contents($path),true);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Asian Countries</title>
        <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    </head>
    <body>
    <div id="main">
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a>&nbsp; <a  href="rest.php"> RestFull Web Service</a></div>
        <h2><center><?php echo $data[0]['name']['common'];?></center></h2>
    <div>
        <div class="row">
        <div class="col-2">&nbsp;</div>
                <div class="col-8">
            <table class="table table-striped ">
            <tr>
                <td colspan="2" style="text-align:center">
                <img src = "<?php echo $data[0]['flags']['png'];?>"" width="220" height="160"/></td>
            </tr>
            <tr>
                <th class="col-2">Official Name</th>
                <th><?php echo $data[0]['name']['official'];?></th>
            </tr>
            <tr>
                <th>Capital</th>
                <th ><?php echo $data [0]['capital'][0];?></th>
            </tr>
            <tr>
                <th>Code</th>
                <th><?php echo $data[0]['cca2'];?></th>
            </tr>
            <tr>
                <th>Currency</th>
                <th>
                <?php
                            $currency_array = $data[0]['currencies'];
                            foreach ($currency_array as $c){
                                $currency=$c['name'];
                                print($currency);
                                echo "</br>";
                            }
                        ?>
                </th>
            </tr>
            <tr>
                <th>Subregion</th>
                <th><?php echo $data[0]['subregion'];?></th>
            </tr>
            <tr>
                <th>Continent</th>
                <th><?php echo $data[0]['region'];?></th>
            </tr>
            <tr>
            <th>Languages</th>
                <th><?php if(isset($data[0]['borders'])){
                    $borders=$data[0]['borders'];
                    echo join(",",$borders);
                }else{
                    echo "No Borders";
                }
                ?></th> 
            </tr>
            <tr><th>Polpulation</th>
                <th><?php echo $data[0]['population'];
                ?></th>
            </tr>
            <tr><th>Area</th>
                <th><?php echo number_format( $data[0]['area'])?></th>
            </tr>
                </div>
            </div>
            </div>
        </div>
    </table>
</html>