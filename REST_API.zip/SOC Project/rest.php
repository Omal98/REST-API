
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>RestFull Web Service</title>
        <meta charset="UTF-8">
        <title>Asian Countries</title>
        <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    </head>
    <body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a>&nbsp; RestFull Web Service</div>
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">&nbsp;</div>
                        <div class="col-md-6" >                           
                            <h5 class="ali">RestFull Web Services</h5>               
  <div class="card">
      
      <div class="card-body">
          <a href="country.php" class="l1">Country Information (Asia)</a>
          <hr />
          <a href="cityinformation.php" class="l1">Search Cities</a>
          <hr />
          <a href="covid19.php" class="l1">COVID-19 Europe</a>
          <hr />
          <a href="covid19chart.php" class="l1">COVID-19 Europe - Chart</a>
          <hr />
          
      </div> 
   
  </div>
                         
                            
                        </div>
                        <div class="col-md-3">&nbsp;</div>
                    </div>
                </div>                  
            </div>
        </div>
    </body>
</html>
