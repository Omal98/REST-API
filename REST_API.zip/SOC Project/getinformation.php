<?php
$c = $_GET['q'];

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://city-and-state-search-api.p.rapidapi.com/search?q=$c",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: city-and-state-search-api.p.rapidapi.com",
        "X-RapidAPI-Key: 7d404d4562mshabcd2912a57ec7ap181217jsna0b7caaf1660"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $c = json_decode($response, true);
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    <title>City Details</title>
</head>
<body>
<div class="container">
    <h1>City Details</h1>
    <table class = "table">
        <thead>
        <tr>
            <th>ID</th>
            <th>City Name</th>
            <th>State Name</th>
            <th>Country Name</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($c as $v) { ?>
            <tr>
                <td><?php echo $v['id']; ?></td>
                <td><?php echo $v['name']; ?></td>
                <td>
                    <?php 
                        if (isset($v['state_name'])) {
                            echo $v['state_name'];
                        }
                        else {
                            echo 'No data available';
                        }
                
                    ?>
                </td>
                <td>
                    <?php
                        if (isset($v['country_name'])) {
                            echo $v['country_name'];
                        }
                        else {
                            echo 'No data available';
                        }
                    ?>
            
                </td>
                <td><a href="citydetails.php?q=<?php echo $v['id'];?>"><?php echo '<button type="button" class="btn btn-success">City Details</button>'; ?></a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>