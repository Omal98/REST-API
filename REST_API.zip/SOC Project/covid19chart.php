<?php

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: covid-193.p.rapidapi.com",
        "X-RapidAPI-Key: 7d404d4562mshabcd2912a57ec7ap181217jsna0b7caaf1660"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $data = json_decode($response, true);
    $c = $data['response'];
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

 
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {


        var dataTable = new google.visualization.DataTable();
        dataTable.addColumn('string', 'Country');
        dataTable.addColumn('number', 'Cases');

        <?php
        foreach ($c as $v) {
            if ($v['continent'] == 'Europe') {

                $countryName = $v['country'];
                $cases = $v['cases']['total'];
            
            echo "dataTable.addRow(['$countryName', $cases]);";
            }
        }
        ?>
        
        var options = {
            'title': 'COVID-19 Cases in European Countries',
            'width': 1000,
            'height': 450
        };

        
        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(dataTable, options);
      }
    </script>
    <title>COVID19 Information </title>
</head>
<body>
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a> &nbsp; <a  href="rest.php"> RestFull Web Service</a></div>
    <div class="container">
        <h1 style="black"><center>COVID19 Information in Europe - Bar Chart</center></h1>
        <div id="chart_div"></div> 
    </div>
</body>
</html>