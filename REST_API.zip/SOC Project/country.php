<?php
//set path
      $path="https://restcountries.com/v3.1/region/asia";
      $data = json_decode(file_get_contents($path),true);
    //var_dump($data);
?>
  <!DOCTYPE html>
<html>
    <head>
        <title>Asian Countries</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" />
    </head>
    <body>
    <div id="main">
<div id="header" class="bg bg-dark text text-white"><center>Research and Development Lab </center></div>
            <div id="navigation" class="container-fluid" align="right" > <a class="li" href="rest.php">Home</a>&nbsp; <a  href="rest.php"> RestFull Web Service</a></div>
        <div class="container">
            <h2 class="text-primary alert"><center>Asian Countries </center></h2>
        <table class="table table-striped">
            <tr>
                <th> Flag </th>
                <th> Country Name </th>
                <th> Capital City </th>
                <th> Region </th>
                <th> Subregion </th>
                <th> Currencies </th> 
                <th> Country Code</th>   
                <th>&nbsp;</th>   
            </tr>
            <?php foreach($data as $value){ ?>
                <tr>
                    
                    <td><img src="<?php echo $value['flags']['png'];?>" width="40" height="20"/></td>
                    <td><?php echo $value['name']['common']; ?></td>
                    <td><?php 
                            if(empty($value['capital'][0])){
                            }
                            else echo $value['capital'][0];
                        ?>
                    </td>
                    <td><?php echo $value['region']; ?></td>
                    <td><?php echo $value['subregion']; ?></td>
                    <td><?php
                            $currency_array = $value['currencies'];
                            foreach ($currency_array as $c){
                                $currency=$c['name'];
                                $symbol=$c['symbol'];
                                print($currency . "(" . $symbol . ")");
                                echo "</br>";
                            }
                        ?>
                </td>
                <td><?php echo $value['cca2']; ?></td>
                <td><a href="countrydetails.php?q=<?php echo $value['cca2'];?>"> 
                <button class="btn btn-success" type="button">View</button></a></td>
            </tr>
           <?php  }?>
           </table> 
        </div>
                        </div>   
    </body>
</html> 
